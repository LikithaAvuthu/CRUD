package Controller;


import Model.Details;
import java.util.List;
import java.util.NoSuchElementException;

import Repository.DetailsRepository;
import Service.DetailsService;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import Exception.RecordNotFoundException;

public class MacDetailsController {

	
	@RestController
	@RequestMapping("/Mac")
	public class WinDetailsController {
		@Autowired
		private DetailsService service;
		
		@GetMapping("/details")
		public List<Details> list() {
		    return service.listAll();
		}
		
		@GetMapping("/details/{name}")
		public ResponseEntity<Details> get(@PathVariable String appName) {
		    try {
		        Details details = service.get(appName);
		        return new ResponseEntity<Details>(details, HttpStatus.OK);
		    } catch (NoSuchElementException e) {
		        return new ResponseEntity<Details>(HttpStatus.NOT_FOUND);
		    }      
		}
		
		@PostMapping("/details")
		public void add(@RequestBody Details details) {
		    service.save(details);
		}
		
		
		@PostMapping("/saveDetails")
		public String insertDetails(Details details)
		{
			service.save(details);
			return "Details Saved Successfully";
		}
		
		@PutMapping("/details/{appName}")
		public ResponseEntity<?> update(@RequestBody Details details, @PathVariable String appName) {
		    try {
		        Details existDetails = service.get(appName);
		        service.save(details);
		        return new ResponseEntity<>(HttpStatus.OK);
		    } catch (NoSuchElementException e) {
		        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		    }      
		}
		
		
		
		@DeleteMapping("/details/{appName}")
		public void delete(@PathVariable String appName) {
		    service.delete(appName);
		}

		
		}
		
		// reading and writing into excel
		
		
		
		
		

	}


