package Repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import Model.Details;


public interface DetailsRepository{
	
		public void readDetails(String appName);
		
		public List<Details> readAllDetails();
		
		public void save();
		
		public void writeDetails(String appName);
	
	

}
