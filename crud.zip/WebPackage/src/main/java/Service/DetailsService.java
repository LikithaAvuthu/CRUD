package Service;


import java.util.List;
import Model.Details;
import Repository.DetailsRepository;
import javax.transaction.Transactional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
@Transactional
public class DetailsService {

	
@Autowired

private DetailsRepository repo;

public List<Details> readAllDetails() {
    return repo.readFromExcel(input);
}
public void save(Details details) {
    repo.save(details);
}
 
public Details get(String appName) {
    return repo.find(appName).get();
}
 
public void delete(String appName) {
    repo.delete(appName);
}
}

