package com.sprinmvc.project.CRUD.controller;

import org.springframework.stereotype.Controller;

import com.sprinmvc.project.CRUD.service.DetailsService;
import com.sprinmvc.project.CRUD.model.Details;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/Win")
public class WinDetailsController {
	
	
	@Autowired private DetailsService detailsService;
	
	@ResponseBody
	@GetMapping(value="/getDetails")
	public String home(Model model)
	{
		//model.addAttribute("detail",new Details());
		Details details= detailsService.findAll();
		//model.addAttribute("details", details);
		return "view/details"; //returns ui page
	}
	
	
	/*@GetMapping("/getDetails/{appName}")
	public String getDetailsByName(Model model)
	{
		model.addAttribute("detail",new Details());
		List<Details> details= detailsService.findByName(details.getByName());
		model.addAttribute("details", details);
		return "view/Byname";
	}*/
	
	@PostMapping(value="/details")
	public String uploadDetails(@ModelAttribute Details details , RedirectAttributes redirectattributes)
	{
		boolean isFlag= detailsService.saveDataFromForm(details.getAppName());
		if(isFlag)
		{
			redirectattributes.addFlashAttribute("successmessage","Details added to the file Successfully!");
		}
		else
		{
			redirectattributes.addFlashAttribute("failuremessage","Details couldn't be added to the file.Please Try Again!");
		}
		
		return "redirect:/";
	}
}
