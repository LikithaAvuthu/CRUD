package com.sprinmvc.project.CRUD.model;




//@Entity
//@Table(name="input")

public class Details {
	
	//@Column(name="AppName")
	private String appName;
	
	private /*@Id @GeneratedValue(strategy=GenerationType.IDENTITY) */long appId;
	
	//@Column(name="AppVersion")
	private double appVersion;
	
	//@Column(name="AppType")
	private String appType;
	
	//@Column(name="MSIPath")
	private String msiPath;
	
	//@Column(name="OS")
	private String os;
	
	//@Column(name="Trigger")
	private boolean trigger;
	
	public Details()
	{
		
	}
	
	
	public Details(String appName, long appId, double appVersion, String appType, String msiPath, String os,
			boolean trigger) {
		super();
		this.appName = appName;
		this.appId = appId;
		this.appVersion = appVersion;
		this.appType = appType;
		this.msiPath = msiPath;
		this.os = os;
		this.trigger = trigger;
	}
	
	
	
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public long getAppId() {
		return appId;
	}
	public void setAppId(long appId) {
		this.appId = appId;
	}
	public double getAppVersion() {
		return appVersion;
	}
	public void setAppVersion(double appVersion) {
		this.appVersion = appVersion;
	}
	public String getAppType() {
		return appType;
	}
	public void setAppType(String appType) {
		this.appType = appType;
	}
	public String getMsiPath() {
		return msiPath;
	}
	public void setMsiPath(String msiPath) {
		this.msiPath = msiPath;
	}
	public String getOs() {
		return os;
	}
	public void setOs(String os) {
		this.os = os;
	}
	public boolean isTrigger() {
		return trigger;
	}
	public void setTrigger(boolean trigger) {
		this.trigger = trigger;
	}

	@Override
	public String toString() {
		return "Details [AppName=" + appName + ", AppId=" + appId + ", AppVersion=" + appVersion + ", AppType="
				+ appType + ", MSIPath=" + msiPath + ", OS=" + os + ", Trigger=" + trigger + "]";
	}
	
	
	
}
