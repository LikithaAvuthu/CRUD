package com.sprinmvc.project.CRUD.service;

import java.util.List;

import com.sprinmvc.project.CRUD.model.Details;

public interface DetailsService {

	Details findAll();

	boolean saveDataFromForm(String appName);

	String findByName(String appName);

}
