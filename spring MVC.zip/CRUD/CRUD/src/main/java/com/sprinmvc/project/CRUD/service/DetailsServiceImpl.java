package com.sprinmvc.project.CRUD.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

//import org.springframework.transaction.annotation.Transactional;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sprinmvc.project.CRUD.model.Details;

@Service

public class DetailsServiceImpl implements DetailsService{

	@Autowired private DetailsService detailsService;
	@Override
	public Details findAll() {
		// TODO Auto-generated method stub
		//List<Details> list= new List<Details>();
		Details details =new Details();
		StringBuilder str = new StringBuilder();
		XSSFWorkbook myExcelBook;
		try {
			myExcelBook = new XSSFWorkbook(new FileInputStream("input.xlsx"));
			String sheetName = myExcelBook.getSheetName(0);
		    XSSFSheet myExcelSheet = myExcelBook.getSheet(sheetName);
		    Iterator<Row> rows= myExcelSheet.iterator();
		   // rows.next();
	    System.out.println("Inside details");
		    for(Row row:myExcelSheet)
		    {
		    	//Details details =new Details();
		    	/*for(Cell cell :row)
		    	{
		    		String cellval = cell.toString()+"\t";
		            str.append(cell.);
		    		System.out.println(str);
		    	}*/
		    	details.setAppName(row.getCell(0).toString());
		    	System.out.println(" Name:"+row.getCell(0).toString());
		    }
		
		
		//return detailsService.findAll();
		} catch(IOException e){
			e.printStackTrace();
		}
		return details;// should return a list
			
		}
	
	@Override
	public boolean saveDataFromForm(String appName) {
		
		StringBuilder str = new StringBuilder();
		XSSFWorkbook myExcelBook;
		try {
			myExcelBook = new XSSFWorkbook(new FileInputStream("input.xlsx"));
			String sheetName = myExcelBook.getSheetName(0);
		    XSSFSheet myExcelSheet = myExcelBook.getSheet(sheetName);
		    Iterator<Row> rows= myExcelSheet.iterator();
		    rows.next();
		    while(rows.hasNext())
		    {
		    	Row row= rows.next();
		    	Details details= new Details();
		    	if(row.getCell(0).getCellType()==Cell.CELL_TYPE_STRING)
		    	{
		    		details.setAppName(row.getCell(0).getStringCellValue());
		    	}
		    	
		    	
		    	
		    	if(row.getCell(1).getCellType()==Cell.CELL_TYPE_NUMERIC)		    	
		    	{
		    		//String appVersion= NumberToTextConverter.toText(row.getCell(2).getNumericCellValue());
		    		details.setAppVersion(row.getCell(1).getNumericCellValue());
		    	}
		    	if(row.getCell(2).getCellType()==Cell.CELL_TYPE_NUMERIC)		    	
		    	{
		    		//String appVersion= NumberToTextConverter.toText(row.getCell(2).getNumericCellValue());
		    		details.setAppVersion(row.getCell(2).getNumericCellValue());
		    	}
		    	if(row.getCell(3).getCellType()==Cell.CELL_TYPE_STRING)
		    	{
		    		details.setAppType(row.getCell(3).getStringCellValue());
		    	}
		    	if(row.getCell(4).getCellType()==Cell.CELL_TYPE_STRING)
		    	{
		    		details.setMsiPath(row.getCell(4).getStringCellValue());
		    	}
		    	if(row.getCell(5).getCellType()==Cell.CELL_TYPE_STRING)
		    	{
		    		details.setOs(row.getCell(5).getStringCellValue());
		    	}
		    	if(row.getCell(6).getCellType()==Cell.CELL_TYPE_STRING)
		    	{
		    		details.setAppName(row.getCell(6).getStringCellValue());
		    	}
		    }
		    
		   // myExcelSheet.createRow(rowCount+1);
		    
		  	
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch blocks
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return true;
	}
	


	@Override
	public String findByName(String appName) {
		
		
			// TODO Auto-generated method stub
			StringBuilder str = new StringBuilder();
			XSSFWorkbook myExcelBook;
			try {
				myExcelBook = new XSSFWorkbook(new FileInputStream("input.xlsx"));
				String sheetName = myExcelBook.getSheetName(0);
			    XSSFSheet myExcelSheet = myExcelBook.getSheet(sheetName);
			    Iterator<Row> rows= myExcelSheet.iterator();
				   // rows.next();
				    for(Row row:myExcelSheet)
				    {
				    	for(Cell cell :row)
				    	{
				    		//shold compare the cell value and appname
				    		
				    		
				    		String cellval = cell.toString()+"\t";
				            str.append(cellval+"\n");
				    		System.out.println(str);
				    		
				    		
				    	}
				    }
			  //	myExcelBook.close();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			return str.toString();

			
	
	}
		
	

}
